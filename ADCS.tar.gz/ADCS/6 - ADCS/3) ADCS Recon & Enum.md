- Let’s start the enumeration with certipy
`certipy find -u khal.drogo@essos.local -p 'horse' -dc-ip 192.168.56.12`

Can also enumerate vulnerable templates:
` certipy find -u khal.drogo@essos.local -p 'horse' -vulnerable -dc-ip 192.168.56.12 -stdout   `