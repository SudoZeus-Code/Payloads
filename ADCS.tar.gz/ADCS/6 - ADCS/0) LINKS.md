https://mayfly277.github.io/posts/GOADv2-pwning-part6/#esc8---coerce-to-domain-admin

https://mayfly277.github.io/posts/GOADv2-pwning-part6/

https://redfoxsec.com/blog/exploiting-active-directory-certificate-services-ad-cs/

https://orange-cyberdefense.github.io/ocd-mindmaps/img/pentest_ad_dark_2022_04.svg

https://github.com/Orange-Cyberdefense/GOAD/blob/main/docs/img/GOAD_schema.png

Coercer:
https://github.com/p0dalirius/Coercer

