in virtual env install certipy
pip install certipy-ad

/home/peter/Desktop/Tools


https://github.com/ly4k/Certipy/wiki/06-%E2%80%90-Privilege-Escalation#esc8-ntlm-relay-to-ad-cs-web-enrollment

